Getestet mit Mozilla-Firefox 60.0.2 (64-Bit) auf Windows 10

Was nicht funktioniert:
- Löschen von Einträgen (der Code ist vorhanden, aber will nicht)
- d3 Opazität
- d3 korrektes Zeichnen der übergebenen Bildpunkte (Holen und Übergeben der Daten funktioniert aber)